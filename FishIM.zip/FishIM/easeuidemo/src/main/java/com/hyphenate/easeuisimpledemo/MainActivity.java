package com.hyphenate.easeuisimpledemo;

import android.os.Bundle;

import com.hyphenate.easeui.ui.EaseBaseActivity;

public class MainActivity extends EaseBaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
